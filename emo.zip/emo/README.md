# Real-Time Emotion Detector

A web application that detects emotions in real-time using your webcam. Built with Flask, DeepFace, and modern web technologies.

## Features
- Real-time emotion detection
- Beautiful animated UI
- Webcam integration
- Responsive design

## Setup
1. Install dependencies:
```bash
pip install flask flask-cors deepface opencv-python numpy
```

2. Run the application:
```bash
python app.py
```

3. Open http://localhost:5000 in your browser

## Technologies Used
- Flask (Backend)
- DeepFace (Emotion Detection)
- HTML5/CSS3 (Frontend)
- JavaScript (Frontend)
