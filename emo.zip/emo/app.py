from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from deepface import DeepFace
import base64
import cv2
import numpy as np
import os # <-- IMPORTED OS FOR ROBUST PATH RESOLUTION

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": "*",
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "expose_headers": ["Content-Range", "X-Content-Range"],
        "supports_credentials": True
    }
})

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# Get the absolute path of the current directory, which makes file serving more reliable
BASE_DIR = os.getcwd()

# 1. Root route now serves the landing page
@app.route('/')
def home():
    # Use BASE_DIR to explicitly look for the file in the current folder
    return send_from_directory(BASE_DIR, 'landingpage.html')

# 2. New route for the main application
@app.route('/app')
def main_app():
    # Use BASE_DIR to explicitly look for the file in the current folder
    return send_from_directory(BASE_DIR, 'index.html')

# 3. FIX: Robust route to serve static files (like the video: 290794.mp4).
# This route catches requests for files not handled by the main app routes.
@app.route('/<path:filename>')
def serve_assets(filename):
    # This ensures any file name requested (like the video) is served from the current directory
    return send_from_directory(BASE_DIR, filename)

@app.route('/analyze', methods=['POST', 'OPTIONS'])
def analyze():
    if request.method == 'OPTIONS':
        return jsonify({}), 200
        
    data = request.get_json()
    image_data = data['image'].split(',')[1]
    image_bytes = base64.b64decode(image_data)
    np_arr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    # The enforce_detection=False flag is already present, which is good for quick demos.
    result = DeepFace.analyze(img, actions=['emotion'], enforce_detection=False)
    emotion = result[0]['dominant_emotion']
    return jsonify({'emotion': emotion})

if __name__ == '__main__':
    # Running on port 5000 by default, as expected by the frontend.
    app.run(debug=True)